Safety Officer Knowledge Hub — วิธีเผยแพร่เว็บไซต์

ไฟล์ที่ต้องใช้
- index.html: เว็บไซต์หลัก

วิธีเผยแพร่ด้วย GitHub Pages
1. เข้า https://github.com และลงชื่อเข้าใช้
2. สร้าง Repository ใหม่ เช่น safety-officer-knowledge-hub
3. ตั้งเป็น Public หากต้องการให้คนทั่วไปเข้าดูได้
4. Upload files แล้วอัปโหลด index.html (จะอัปโหลด README_TH.txt ด้วยก็ได้)
5. กด Commit changes
6. เปิด Settings > Pages
7. ใน Build and deployment เลือก Deploy from a branch
8. เลือก Branch: main และ Folder: / (root) จากนั้น Save
9. รอให้ GitHub Pages แสดง URL ของเว็บไซต์ในหน้า Settings > Pages

วิธีนำไปฝังใน Google Sites
1. เปิด Google Sites แล้วเข้าไซต์ที่ต้องการแก้ไข
2. เลือก Insert > Embed
3. เลือก By URL แล้ววาง URL ที่ได้จาก GitHub Pages
4. กด Insert แล้วปรับขนาดกรอบให้เหมาะสม
5. กด Publish ใน Google Sites

ข้อควรรู้
- ต้องเผยแพร่ HTML ให้เป็น URL แบบ https:// ก่อนจึงจะฝังผ่าน URL ได้
- Google Sites อาจแสดงหน้าเว็บในกรอบฝัง (iframe); ถ้าพื้นที่แสดงผลแคบ ให้ปรับความสูง/ความกว้าง หรือเพิ่มปุ่มเปิดเว็บไซต์เต็มหน้าแทน
- เว็บไซต์นี้ใช้ไลบรารีจาก CDN บางรายการ เช่น Tailwind CSS และ SheetJS จึงต้องเชื่อมต่ออินเทอร์เน็ตเพื่อให้ฟังก์ชันที่เกี่ยวข้องทำงาน
- ข้อมูลที่บันทึกในเบราว์เซอร์เป็นข้อมูลแยกตามอุปกรณ์/โปรไฟล์เบราว์เซอร์ ไม่ใช่ฐานข้อมูลกลางที่ผู้เข้าชมทุกคนเห็นร่วมกัน
- อย่าใส่ข้อมูลส่วนบุคคลหรือเอกสารลับของบริษัทในไฟล์ HTML ที่เผยแพร่สาธารณะ
